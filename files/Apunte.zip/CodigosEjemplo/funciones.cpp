#include <iostream>

using namespace std;

int suma(int a, int b){
	int r;
	r = a + b;
	return r;
}

int main()
{
    cout << suma(1,2) << endl;

    return 0;
}
