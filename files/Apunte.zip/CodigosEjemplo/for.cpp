#include <iostream>

using namespace std;

int main()
{
    int n;
    for(n=1;n<3;n++){
        cout << n << endl;
    }

    return 0;
}
