/* Programa de ejemplo
para el apunte
*/
#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world!" << endl; // Muestra el mensaje "Hola mundo!"
    return /*esto no afecta al codigo*/0;
}
