#include <iostream>

using namespace std;

int main()
{
    int x;

    cout << "Ingrese un valor: ";
    cin >> x;
    cout << "El valor ingresado es: " << x << endl;

    return 0;
}
