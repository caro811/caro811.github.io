// Comentario hasta el final de la linea
/* comentario
de varias
lineas */
/** comentario de varias lineas
con otro color (en algunos editores, no en todos) */
/* este comentario puede inscrutarse en el medio del codigo */
