#include <iostream>

using namespace std;

int main()
{
    int a,b;
    a = 8;
    b = 3;

    return 0;
}
