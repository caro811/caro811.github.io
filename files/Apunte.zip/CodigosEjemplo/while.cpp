#include <iostream>

using namespace std;

int main()
{
    int n;
    n = 1;
    while(n < 3){
        cout << n << endl;
        n = n + 1;
    }

    return 0;
}
