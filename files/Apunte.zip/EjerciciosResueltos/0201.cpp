#include <iostream>

using namespace std;

int main()
{
    cout << "Nombre\tNota1\tNota2" << endl;
    cout << "Ana\t7\t8" << endl;
    cout << "Daniel\t5\t3" << endl;
    cout << "Ovidio\t10\t10" << endl;

    return 0;
}
