#include <iostream>

using namespace std;

int main()
{
    cout << "+--------+-------+-------+" << endl;
    cout << "| Nombre | Nota1 | Nota2 |" << endl;
    cout << "+--------+-------+-------+" << endl;
    cout << "| Ana    |   7   |   8   |" << endl;
    cout << "+--------+-------+-------+" << endl;
    cout << "| Daniel |   5   |   3   |" << endl;
    cout << "+--------+-------+-------+" << endl;
    cout << "| Ovidio |   10  |   10  |" << endl;
    cout << "+--------+-------+-------+" << endl;

    return 0;
}
