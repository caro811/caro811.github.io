#include <iostream>

using namespace std;

int main()
{
    char nombre[100], apellido[100];

    cin >> nombre >> apellido;

    cout << apellido << ", " << nombre << endl;

    return 0;
}
