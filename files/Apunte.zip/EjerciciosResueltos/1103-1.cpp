#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    freopen("1103.txt","w",stdout);

    int n = 10000;
    for(int i=0;i<n;i++)
        cout << i << endl;

    return 0;
}
